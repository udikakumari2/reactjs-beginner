# CalculatorAndroid
Fully functionable calculator app in Android Studio
Youtube Tutorial here : https://youtu.be/X3KQdwVlo1Q

![calculator](https://user-images.githubusercontent.com/68380115/169702523-1a5d826d-fb0f-4377-bc58-f62d4ca53535.jpg)
